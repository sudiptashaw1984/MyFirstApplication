using Microsoft.AspNetCore.Mvc;
using HospitalAPI.Data;
using HospitalAPI.Models;
using System.Linq;

namespace HospitalAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PatientsController : ControllerBase
    {
        private readonly AppDbContext _db;

        public PatientsController(AppDbContext db)
        {
            _db = db;
            if(!_db.Patients.Any())
            {
                _db.Patients.Add(new Patient{ Name="Demo", Gender="M", Phone="999"});
                _db.SaveChanges();
            }
        }

        [HttpGet]
        public IActionResult Get() => Ok(_db.Patients.ToList());

        [HttpPost]
        public IActionResult Post(Patient p)
        {
            _db.Patients.Add(p);
            _db.SaveChanges();
            return Ok(p);
        }
    }
}